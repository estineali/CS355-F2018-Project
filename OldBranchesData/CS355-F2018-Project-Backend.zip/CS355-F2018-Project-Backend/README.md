# CS355 Database Systems - Fall 2018
	
	Final Project - Khana Mangwana
	
	The Red Roasted Parakeets : 
        Alina Qureshi 
        Ali Shujjat 
        Muhammad Shahrom Ali
	
	Habib University
	
  Copyright (C) The Red Roasted Parakeets - All Rights Reserved
	
	Unauthorized copying of this file, via any medium, is strictly prohibited
	Proprietary and confidential
  
  Written by Muhammad Shahrom Ali <estineali@gmail.com>, November 2018
