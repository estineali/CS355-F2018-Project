﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KhanaMangwana
{
    public partial class SysAdmin_AdminDetails : Form
    {
        public SysAdmin_AdminDetails()
        {
            InitializeComponent();
        }
    }
}

/*Select First Name, Last Name, Username, Email, Age from Users where isAdmin = true*/