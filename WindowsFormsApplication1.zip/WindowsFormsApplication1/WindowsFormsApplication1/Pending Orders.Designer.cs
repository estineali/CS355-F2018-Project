﻿namespace WindowsFormsApplication1
{
    partial class Pending_Orders
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Order_details = new System.Windows.Forms.Button();
            this.Cancel = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // Order_details
            // 
            this.Order_details.Location = new System.Drawing.Point(203, 267);
            this.Order_details.Name = "Order_details";
            this.Order_details.Size = new System.Drawing.Size(75, 23);
            this.Order_details.TabIndex = 1;
            this.Order_details.Text = "Order details";
            this.Order_details.UseVisualStyleBackColor = true;
            this.Order_details.Click += new System.EventHandler(this.Order_details_Click);
            // 
            // Cancel
            // 
            this.Cancel.Location = new System.Drawing.Point(284, 267);
            this.Cancel.Name = "Cancel";
            this.Cancel.Size = new System.Drawing.Size(75, 23);
            this.Cancel.TabIndex = 2;
            this.Cancel.Text = "Cancel";
            this.Cancel.UseVisualStyleBackColor = true;
            this.Cancel.Click += new System.EventHandler(this.Cancel_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Items.AddRange(new object[] {
            "06983\tSaleha Raza "});
            this.listBox1.Location = new System.Drawing.Point(16, 25);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(355, 225);
            this.listBox1.TabIndex = 3;
            // 
            // Pending_Orders
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(383, 312);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.Cancel);
            this.Controls.Add(this.Order_details);
            this.Name = "Pending_Orders";
            this.Text = "Pending_Orders";
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button Order_details;
        private System.Windows.Forms.Button Cancel;
        private System.Windows.Forms.ListBox listBox1;
    }
}