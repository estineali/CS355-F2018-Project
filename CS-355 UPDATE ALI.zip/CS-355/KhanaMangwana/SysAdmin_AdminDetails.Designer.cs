﻿namespace KhanaMangwana
{
    partial class SysAdmin_AdminDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SysAdmin_AdminDetails));
            this.Admin_FName = new System.Windows.Forms.Label();
            this.Admin_Name_Text = new System.Windows.Forms.TextBox();
            this.Username_Text = new System.Windows.Forms.TextBox();
            this.Username = new System.Windows.Forms.Label();
            this.Last_Name = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.Email = new System.Windows.Forms.Label();
            this.Email_Text = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.Opening_Date = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // Admin_FName
            // 
            this.Admin_FName.AutoSize = true;
            this.Admin_FName.Location = new System.Drawing.Point(43, 80);
            this.Admin_FName.Name = "Admin_FName";
            this.Admin_FName.Size = new System.Drawing.Size(60, 13);
            this.Admin_FName.TabIndex = 0;
            this.Admin_FName.Text = "First Name:";
            // 
            // Admin_Name_Text
            // 
            this.Admin_Name_Text.Location = new System.Drawing.Point(140, 77);
            this.Admin_Name_Text.Name = "Admin_Name_Text";
            this.Admin_Name_Text.Size = new System.Drawing.Size(177, 20);
            this.Admin_Name_Text.TabIndex = 1;
            // 
            // Username_Text
            // 
            this.Username_Text.Location = new System.Drawing.Point(140, 170);
            this.Username_Text.Name = "Username_Text";
            this.Username_Text.Size = new System.Drawing.Size(177, 20);
            this.Username_Text.TabIndex = 2;
            // 
            // Username
            // 
            this.Username.AutoSize = true;
            this.Username.Location = new System.Drawing.Point(45, 170);
            this.Username.Name = "Username";
            this.Username.Size = new System.Drawing.Size(58, 13);
            this.Username.TabIndex = 3;
            this.Username.Text = "Username:";
            // 
            // Last_Name
            // 
            this.Last_Name.AutoSize = true;
            this.Last_Name.Location = new System.Drawing.Point(43, 125);
            this.Last_Name.Name = "Last_Name";
            this.Last_Name.Size = new System.Drawing.Size(61, 13);
            this.Last_Name.TabIndex = 4;
            this.Last_Name.Text = "Last Name:";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(140, 125);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(177, 20);
            this.textBox2.TabIndex = 5;
            // 
            // Email
            // 
            this.Email.AutoSize = true;
            this.Email.Location = new System.Drawing.Point(47, 225);
            this.Email.Name = "Email";
            this.Email.Size = new System.Drawing.Size(35, 13);
            this.Email.TabIndex = 6;
            this.Email.Text = "Email:";
            // 
            // Email_Text
            // 
            this.Email_Text.Location = new System.Drawing.Point(140, 222);
            this.Email_Text.Name = "Email_Text";
            this.Email_Text.Size = new System.Drawing.Size(177, 20);
            this.Email_Text.TabIndex = 7;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(140, 268);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(177, 20);
            this.textBox1.TabIndex = 8;
            // 
            // Opening_Date
            // 
            this.Opening_Date.AutoSize = true;
            this.Opening_Date.Location = new System.Drawing.Point(47, 271);
            this.Opening_Date.Name = "Opening_Date";
            this.Opening_Date.Size = new System.Drawing.Size(76, 13);
            this.Opening_Date.TabIndex = 9;
            this.Opening_Date.Text = "Opening Date:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(1, 1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(373, 63);
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.DarkMagenta;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(106, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(181, 31);
            this.label1.TabIndex = 11;
            this.label1.Text = "Admin Details";
            // 
            // SysAdmin_AdminDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(366, 341);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Opening_Date);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.Email_Text);
            this.Controls.Add(this.Email);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.Last_Name);
            this.Controls.Add(this.Username);
            this.Controls.Add(this.Username_Text);
            this.Controls.Add(this.Admin_Name_Text);
            this.Controls.Add(this.Admin_FName);
            this.Name = "SysAdmin_AdminDetails";
            this.Text = "SysAdmin_AdminDetails";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Admin_FName;
        private System.Windows.Forms.TextBox Admin_Name_Text;
        private System.Windows.Forms.TextBox Username_Text;
        private System.Windows.Forms.Label Username;
        private System.Windows.Forms.Label Last_Name;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label Email;
        private System.Windows.Forms.TextBox Email_Text;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label Opening_Date;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
    }
}