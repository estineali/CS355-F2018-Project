﻿namespace KhanaMangwana
{
    partial class SysAdmin_CustomerDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SysAdmin_CustomerDetails));
            this.First_Name = new System.Windows.Forms.Label();
            this.First_Name_Text = new System.Windows.Forms.TextBox();
            this.Last_Name = new System.Windows.Forms.Label();
            this.Last_Name_Text = new System.Windows.Forms.TextBox();
            this.Username_Text = new System.Windows.Forms.TextBox();
            this.Username = new System.Windows.Forms.Label();
            this.Email = new System.Windows.Forms.Label();
            this.Email_Text = new System.Windows.Forms.TextBox();
            this.Birth = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // First_Name
            // 
            this.First_Name.AutoSize = true;
            this.First_Name.Location = new System.Drawing.Point(50, 98);
            this.First_Name.Name = "First_Name";
            this.First_Name.Size = new System.Drawing.Size(60, 13);
            this.First_Name.TabIndex = 0;
            this.First_Name.Text = "First Name:";
            // 
            // First_Name_Text
            // 
            this.First_Name_Text.Location = new System.Drawing.Point(125, 95);
            this.First_Name_Text.Name = "First_Name_Text";
            this.First_Name_Text.Size = new System.Drawing.Size(184, 20);
            this.First_Name_Text.TabIndex = 1;
            // 
            // Last_Name
            // 
            this.Last_Name.AutoSize = true;
            this.Last_Name.Location = new System.Drawing.Point(50, 147);
            this.Last_Name.Name = "Last_Name";
            this.Last_Name.Size = new System.Drawing.Size(61, 13);
            this.Last_Name.TabIndex = 2;
            this.Last_Name.Text = "Last Name:";
            // 
            // Last_Name_Text
            // 
            this.Last_Name_Text.Location = new System.Drawing.Point(125, 140);
            this.Last_Name_Text.Name = "Last_Name_Text";
            this.Last_Name_Text.Size = new System.Drawing.Size(184, 20);
            this.Last_Name_Text.TabIndex = 3;
            // 
            // Username_Text
            // 
            this.Username_Text.Location = new System.Drawing.Point(125, 190);
            this.Username_Text.Name = "Username_Text";
            this.Username_Text.Size = new System.Drawing.Size(184, 20);
            this.Username_Text.TabIndex = 4;
            // 
            // Username
            // 
            this.Username.AutoSize = true;
            this.Username.Location = new System.Drawing.Point(53, 197);
            this.Username.Name = "Username";
            this.Username.Size = new System.Drawing.Size(58, 13);
            this.Username.TabIndex = 5;
            this.Username.Text = "Username:";
            // 
            // Email
            // 
            this.Email.AutoSize = true;
            this.Email.Location = new System.Drawing.Point(53, 246);
            this.Email.Name = "Email";
            this.Email.Size = new System.Drawing.Size(35, 13);
            this.Email.TabIndex = 6;
            this.Email.Text = "Email:";
            // 
            // Email_Text
            // 
            this.Email_Text.Location = new System.Drawing.Point(125, 243);
            this.Email_Text.Name = "Email_Text";
            this.Email_Text.Size = new System.Drawing.Size(184, 20);
            this.Email_Text.TabIndex = 7;
            // 
            // Birth
            // 
            this.Birth.AutoSize = true;
            this.Birth.Location = new System.Drawing.Point(53, 298);
            this.Birth.Name = "Birth";
            this.Birth.Size = new System.Drawing.Size(69, 13);
            this.Birth.TabIndex = 8;
            this.Birth.Text = "Date of Birth:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(125, 295);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(184, 20);
            this.textBox1.TabIndex = 9;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(-2, -1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(357, 63);
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.DarkMagenta;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(77, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(223, 31);
            this.label1.TabIndex = 11;
            this.label1.Text = "Customer Details";
            // 
            // SysAdmin_CustomerDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(351, 341);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.Birth);
            this.Controls.Add(this.Email_Text);
            this.Controls.Add(this.Email);
            this.Controls.Add(this.Username);
            this.Controls.Add(this.Username_Text);
            this.Controls.Add(this.Last_Name_Text);
            this.Controls.Add(this.Last_Name);
            this.Controls.Add(this.First_Name_Text);
            this.Controls.Add(this.First_Name);
            this.Controls.Add(this.pictureBox1);
            this.Name = "SysAdmin_CustomerDetails";
            this.Text = "SysAdmin_CustomerDetails";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label First_Name;
        private System.Windows.Forms.TextBox First_Name_Text;
        private System.Windows.Forms.Label Last_Name;
        private System.Windows.Forms.TextBox Last_Name_Text;
        private System.Windows.Forms.TextBox Username_Text;
        private System.Windows.Forms.Label Username;
        private System.Windows.Forms.Label Email;
        private System.Windows.Forms.TextBox Email_Text;
        private System.Windows.Forms.Label Birth;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
    }
}