﻿namespace KhanaMangwana
{
    partial class SystemAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SystemAdmin));
            this.SysAdminLabel = new System.Windows.Forms.Label();
            this.AdminsButton = new System.Windows.Forms.Button();
            this.CustomersButton = new System.Windows.Forms.Button();
            this.OrdersButton = new System.Windows.Forms.Button();
            this.ComplaintsButton = new System.Windows.Forms.Button();
            this.LogoutButton = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // SysAdminLabel
            // 
            this.SysAdminLabel.AutoSize = true;
            this.SysAdminLabel.BackColor = System.Drawing.Color.DarkMagenta;
            this.SysAdminLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SysAdminLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.SysAdminLabel.Location = new System.Drawing.Point(77, 19);
            this.SysAdminLabel.Name = "SysAdminLabel";
            this.SysAdminLabel.Size = new System.Drawing.Size(188, 31);
            this.SysAdminLabel.TabIndex = 0;
            this.SysAdminLabel.Text = "System Admin";
            // 
            // AdminsButton
            // 
            this.AdminsButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AdminsButton.Location = new System.Drawing.Point(21, 89);
            this.AdminsButton.Name = "AdminsButton";
            this.AdminsButton.Size = new System.Drawing.Size(279, 35);
            this.AdminsButton.TabIndex = 1;
            this.AdminsButton.Text = "Admins";
            this.AdminsButton.UseVisualStyleBackColor = true;
            this.AdminsButton.Click += new System.EventHandler(this.AdminsButton_Click);
            // 
            // CustomersButton
            // 
            this.CustomersButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CustomersButton.Location = new System.Drawing.Point(21, 150);
            this.CustomersButton.Name = "CustomersButton";
            this.CustomersButton.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.CustomersButton.Size = new System.Drawing.Size(279, 35);
            this.CustomersButton.TabIndex = 2;
            this.CustomersButton.Text = "Customers";
            this.CustomersButton.UseVisualStyleBackColor = true;
            this.CustomersButton.Click += new System.EventHandler(this.CustomersButton_Click);
            // 
            // OrdersButton
            // 
            this.OrdersButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OrdersButton.Location = new System.Drawing.Point(21, 208);
            this.OrdersButton.Name = "OrdersButton";
            this.OrdersButton.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.OrdersButton.Size = new System.Drawing.Size(279, 35);
            this.OrdersButton.TabIndex = 3;
            this.OrdersButton.Text = "Orders";
            this.OrdersButton.UseVisualStyleBackColor = true;
            this.OrdersButton.Click += new System.EventHandler(this.OrdersButton_Click);
            // 
            // ComplaintsButton
            // 
            this.ComplaintsButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ComplaintsButton.Location = new System.Drawing.Point(21, 264);
            this.ComplaintsButton.Name = "ComplaintsButton";
            this.ComplaintsButton.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ComplaintsButton.Size = new System.Drawing.Size(279, 35);
            this.ComplaintsButton.TabIndex = 4;
            this.ComplaintsButton.Text = "Complaints";
            this.ComplaintsButton.UseVisualStyleBackColor = true;
            this.ComplaintsButton.Click += new System.EventHandler(this.ComplaintsButton_Click);
            // 
            // LogoutButton
            // 
            this.LogoutButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LogoutButton.Location = new System.Drawing.Point(21, 317);
            this.LogoutButton.Name = "LogoutButton";
            this.LogoutButton.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.LogoutButton.Size = new System.Drawing.Size(279, 35);
            this.LogoutButton.TabIndex = 5;
            this.LogoutButton.Text = "Logout";
            this.LogoutButton.UseVisualStyleBackColor = true;
            this.LogoutButton.Click += new System.EventHandler(this.LogoutButton_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(-3, -2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(334, 65);
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // SystemAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(329, 311);
            this.Controls.Add(this.LogoutButton);
            this.Controls.Add(this.ComplaintsButton);
            this.Controls.Add(this.OrdersButton);
            this.Controls.Add(this.CustomersButton);
            this.Controls.Add(this.AdminsButton);
            this.Controls.Add(this.SysAdminLabel);
            this.Controls.Add(this.pictureBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "SystemAdmin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "System Admin";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label SysAdminLabel;
        private System.Windows.Forms.Button AdminsButton;
        private System.Windows.Forms.Button CustomersButton;
        private System.Windows.Forms.Button OrdersButton;
        private System.Windows.Forms.Button ComplaintsButton;
        private System.Windows.Forms.Button LogoutButton;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}