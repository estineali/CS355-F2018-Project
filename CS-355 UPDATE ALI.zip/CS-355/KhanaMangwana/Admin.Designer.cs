﻿namespace KhanaMangwana
{
    partial class Admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Admin));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.PendingOrdersLink = new System.Windows.Forms.LinkLabel();
            this.AllOrderslink = new System.Windows.Forms.LinkLabel();
            this.EditMenulink = new System.Windows.Forms.LinkLabel();
            this.LogoutLink = new System.Windows.Forms.LinkLabel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.DarkMagenta;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(87, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(249, 31);
            this.label1.TabIndex = 2;
            this.label1.Text = "ADMINISTRATION";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(150, 89);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 24);
            this.label2.TabIndex = 3;
            this.label2.Text = "Welcome!";
            // 
            // PendingOrdersLink
            // 
            this.PendingOrdersLink.AutoSize = true;
            this.PendingOrdersLink.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PendingOrdersLink.LinkColor = System.Drawing.Color.DimGray;
            this.PendingOrdersLink.Location = new System.Drawing.Point(122, 136);
            this.PendingOrdersLink.Name = "PendingOrdersLink";
            this.PendingOrdersLink.Size = new System.Drawing.Size(162, 25);
            this.PendingOrdersLink.TabIndex = 4;
            this.PendingOrdersLink.TabStop = true;
            this.PendingOrdersLink.Text = "Pending Orders";
            this.PendingOrdersLink.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // AllOrderslink
            // 
            this.AllOrderslink.AutoSize = true;
            this.AllOrderslink.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AllOrderslink.LinkColor = System.Drawing.Color.DimGray;
            this.AllOrderslink.Location = new System.Drawing.Point(149, 187);
            this.AllOrderslink.Name = "AllOrderslink";
            this.AllOrderslink.Size = new System.Drawing.Size(107, 25);
            this.AllOrderslink.TabIndex = 5;
            this.AllOrderslink.TabStop = true;
            this.AllOrderslink.Text = "All Orders";
            this.AllOrderslink.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel2_LinkClicked);
            // 
            // EditMenulink
            // 
            this.EditMenulink.AutoSize = true;
            this.EditMenulink.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EditMenulink.LinkColor = System.Drawing.Color.DimGray;
            this.EditMenulink.Location = new System.Drawing.Point(149, 245);
            this.EditMenulink.Name = "EditMenulink";
            this.EditMenulink.Size = new System.Drawing.Size(109, 25);
            this.EditMenulink.TabIndex = 7;
            this.EditMenulink.TabStop = true;
            this.EditMenulink.Text = "Edit Menu";
            this.EditMenulink.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.EditMenu_LinkClicked);
            // 
            // LogoutLink
            // 
            this.LogoutLink.AutoSize = true;
            this.LogoutLink.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LogoutLink.LinkColor = System.Drawing.Color.DimGray;
            this.LogoutLink.Location = new System.Drawing.Point(168, 296);
            this.LogoutLink.Name = "LogoutLink";
            this.LogoutLink.Size = new System.Drawing.Size(78, 25);
            this.LogoutLink.TabIndex = 8;
            this.LogoutLink.TabStop = true;
            this.LogoutLink.Text = "Logout";
            this.LogoutLink.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LogoutLink_LinkClicked);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(397, 68);
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            // 
            // Admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(395, 382);
            this.Controls.Add(this.LogoutLink);
            this.Controls.Add(this.EditMenulink);
            this.Controls.Add(this.AllOrderslink);
            this.Controls.Add(this.PendingOrdersLink);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Admin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Administration";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.LinkLabel PendingOrdersLink;
        private System.Windows.Forms.LinkLabel AllOrderslink;
        private System.Windows.Forms.LinkLabel EditMenulink;
        private System.Windows.Forms.LinkLabel LogoutLink;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

