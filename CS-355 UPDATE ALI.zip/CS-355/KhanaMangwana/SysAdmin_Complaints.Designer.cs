﻿namespace KhanaMangwana
{
    partial class SysAdmin_Complaints
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SysAdmin_Complaints));
            this.ComplaintsHeading = new System.Windows.Forms.Label();
            this.ComplainsListBox = new System.Windows.Forms.ListBox();
            this.BackButton = new System.Windows.Forms.Button();
            this.ResolvedButton = new System.Windows.Forms.Button();
            this.AdminIDLabel = new System.Windows.Forms.Label();
            this.ComplainLabel = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // ComplaintsHeading
            // 
            this.ComplaintsHeading.AutoSize = true;
            this.ComplaintsHeading.BackColor = System.Drawing.Color.DarkMagenta;
            this.ComplaintsHeading.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ComplaintsHeading.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ComplaintsHeading.Location = new System.Drawing.Point(177, 18);
            this.ComplaintsHeading.Name = "ComplaintsHeading";
            this.ComplaintsHeading.Size = new System.Drawing.Size(150, 31);
            this.ComplaintsHeading.TabIndex = 0;
            this.ComplaintsHeading.Text = "Complaints";
            // 
            // ComplainsListBox
            // 
            this.ComplainsListBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ComplainsListBox.FormattingEnabled = true;
            this.ComplainsListBox.ItemHeight = 18;
            this.ComplainsListBox.Items.AddRange(new object[] {
            "6\t\"Can not receive Orders\"",
            "6\t\"Can not update order status for a certain customer\""});
            this.ComplainsListBox.Location = new System.Drawing.Point(37, 110);
            this.ComplainsListBox.Name = "ComplainsListBox";
            this.ComplainsListBox.Size = new System.Drawing.Size(450, 274);
            this.ComplainsListBox.TabIndex = 1;
            // 
            // BackButton
            // 
            this.BackButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BackButton.Location = new System.Drawing.Point(320, 406);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(75, 23);
            this.BackButton.TabIndex = 2;
            this.BackButton.Text = "Back";
            this.BackButton.UseVisualStyleBackColor = true;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // ResolvedButton
            // 
            this.ResolvedButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ResolvedButton.Location = new System.Drawing.Point(412, 406);
            this.ResolvedButton.Name = "ResolvedButton";
            this.ResolvedButton.Size = new System.Drawing.Size(75, 23);
            this.ResolvedButton.TabIndex = 3;
            this.ResolvedButton.Text = "Resolved";
            this.ResolvedButton.UseVisualStyleBackColor = true;
            this.ResolvedButton.Click += new System.EventHandler(this.ResolvedButton_Click);
            // 
            // AdminIDLabel
            // 
            this.AdminIDLabel.AutoSize = true;
            this.AdminIDLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AdminIDLabel.Location = new System.Drawing.Point(34, 82);
            this.AdminIDLabel.Name = "AdminIDLabel";
            this.AdminIDLabel.Size = new System.Drawing.Size(47, 13);
            this.AdminIDLabel.TabIndex = 4;
            this.AdminIDLabel.Text = "AdminID";
            // 
            // ComplainLabel
            // 
            this.ComplainLabel.AutoSize = true;
            this.ComplainLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ComplainLabel.Location = new System.Drawing.Point(109, 82);
            this.ComplainLabel.Name = "ComplainLabel";
            this.ComplainLabel.Size = new System.Drawing.Size(50, 13);
            this.ComplainLabel.TabIndex = 5;
            this.ComplainLabel.Text = "Complain";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, -1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(543, 63);
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // SysAdmin_Complaints
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(546, 450);
            this.Controls.Add(this.ComplainLabel);
            this.Controls.Add(this.AdminIDLabel);
            this.Controls.Add(this.ResolvedButton);
            this.Controls.Add(this.BackButton);
            this.Controls.Add(this.ComplainsListBox);
            this.Controls.Add(this.ComplaintsHeading);
            this.Controls.Add(this.pictureBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "SysAdmin_Complaints";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Complaints";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label ComplaintsHeading;
        private System.Windows.Forms.ListBox ComplainsListBox;
        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.Button ResolvedButton;
        private System.Windows.Forms.Label AdminIDLabel;
        private System.Windows.Forms.Label ComplainLabel;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}